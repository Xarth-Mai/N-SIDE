# N:SIDE 文档与任务体系重构方案

基线：`a0deb64e1447d84ab7161e494ee1748de279090c`。本方案已确定信息架构与实施顺序，供 Codex 接手实施，不要求再次从零规划。实际工作区有后续变化时，先做差异合并。

## 1. 目标与范围

保留现有设定、稳定对象 ID、源资产、合法来源和有价值的专业 Skills，重建文档规范、开发手册与任务管线。游戏实现仅作引用和回归对象；本轮不更换引擎、不重写玩法、不批量重做美术，也不引入在线 Agent 作为游戏运行依赖。

完成后的四个职责：

| 位置 | 唯一职责 |
|---|---|
| docs/player | 玩家阅读的百科、故事与可玩版本指南 |
| docs/dev | 开发目标、具体设计、工程契约、制作方法、验收标准 |
| .agents/skills | Codex 如何执行专业工作的可复用方法与工具入口 |
| todo | 本次做什么、依赖什么、实际结果、阻碍和证据 |

作者的名字、原始版权与许可证是归属信息，随着采用内容迁移，不因“项目化”而消失。专业方法有出处，项目决定有依据，执行完成有证据。

## 2. 目标目录

```text
AGENTS.md
README.md
THIRD_PARTY_NOTICES.md
.agents/skills/                       # 已整合专业技能为主，保留作者与名称
third_party/skills/                   # 来源、许可、固定版本、必要参考
source-assets/                       # 继续作为源资产与地图主数据所在位置

docs/
  index.md                           # 源码知识导航；可生成读者入口
  player/
    index.md
    guide/                           # 版本相关操作与玩法帮助
    encyclopedia/
      world/
      characters/
      locations/
      story/
      enemies/
      gameplay/                      # 世界内机制/概念，不等同操作指南
  dev/
    index.md
    direction/                       # 愿景、体验支柱、完整游戏/Demo 范围
    design/
      systems/
      quests/
      characters/
      locations/
      catalogs/                      # 既有角色/任务/场所机器索引，非新台账
    engineering/
    production/
    validation/
    handbook/
      templates/
    decisions/
  .vitepress/                        # 共享主题、配置、按读者生成导航
  public/                            # 迁移时按受众和引用审查，不能全量盲拷

todo/
  README.md                          # 自动生成的当前看板
  roadmap.md                         # 人维护的里程碑目标与门槛，不手填任务状态
  tasks/
    TASK-xxx-short-title.md           # 单项工作的唯一编辑源，路径稳定
  evidence/
    TASK-xxx/
      run-id/
  archive/
    legacy/
```

这些目录按内容逐步落地，不生成空架子。runtime assets 仍在 game/assets，文档迁移不以改变源资产结构为前提。

## 3. 文档规范

### 3.1 一页一个主要阅读任务

百科解释对象及其经历；操作指南说明如何完成玩家动作；设计规格定义规则与状态；制作指南提供输入到交付的方法；技术参考解释契约；决策记录保存重要取舍。不要求每篇页面套同一套大表格。

玩家百科可以完整披露故事和结局，通过入口/章级剧透提示组织，不把完整设定删成宣传简介。操作指南按实际可玩版本编写；尚无对应实现时保留设计资料，不编造按键、数值或完成度。

同一对象的百科与开发规格通过对象 ID/链接关联。已公开的故事事实在百科正文维护，开发规格引用再补玩家动作、状态、演出和验收。作者专用事实保存在指定开发主题，按发布范围形成玩家投影；不人为为每个对象制造双份全文。

### 3.2 元数据分工

对象身份继续用 CHR/LOC/QST/AST 等原 ID；文档自身需要引用时用独立 DOC ID。一个页面的 document_id 与其 subject_id 不是一回事。迁移工具必须识别旧 id 用于对象还是文档，保留映射，不靠全局字符串替换更换身份。

读者由目录决定，不另维护容易冲突的 audience 字段。开发设计可采用 draft/accepted/superseded；既有 approved 映射为 accepted 并记录，不代表重新批准。设计状态与实现状态分开。玩家页面的技术元数据不渲染成内部字段表。

元数据仅包含实际需要的字段。标题来自一级标题，避免再保存一个会漂移的 title。

### 3.3 内容与证据分离

长期规范描述当前有效设计和工作方式，不滚动追加每次调试日志。运行环境、具体命令结果、截图、反馈和失败轨迹留在 todo/evidence 或任务记录。新实验只有得到支持的结论才写回对应规格；未决参数记录假设与所需验证，不提前写成强标准。

项目的世界观与人物同意边界属于设计；“Codex 要调用什么工具”属于开发手册/Skill。按语义审查，不能用“Agent”等词作为玩家文档禁词。

## 4. 具体迁移归属

下表是已确定的模块级规则与关键例外，不冒充逐文件全量迁移已经执行。`03-migration-rules.json` 提供机器可读起点；实施第一步应据此枚举每个实际文件，追加段落拆分和引用修复的具体映射。

| 原位置 | 目标/处理 |
|---|---|
| docs/world/*.md | player/encyclopedia/world，保留完整设定与链接 |
| docs/characters/ 下的 Markdown | player/encyclopedia/characters；发现制作要求时抽到 dev/design/characters 后互引 |
| docs/locations/ 下的 Markdown | player/encyclopedia/locations；空间规格抽到 dev/design/locations |
| docs/story/** | player/encyclopedia/story，保持章序、完整剧情和剧透入口 |
| docs/enemies/** | 玩家事实与开发行为/参数分拆；同对象关联 |
| docs/gameplay/controls.md | 只有实际验证的操作进入 player/guide；未验证动作规格进入 dev/design/systems/input.md |
| docs/gameplay/ 其余主题 | 世界内概念进入 player/encyclopedia/gameplay；具体系统规则进入 dev/design/systems |
| docs/quests/QST-002/** | dev/design/quests/QST-002；已存在故事正文继续留在百科，不再复制 |
| docs/narrative/workflow.md、playtest.md | production/narrative.md、validation/playtesting.md；叙事数据语义留工程/设计契约 |
| docs/narrative/data.md | dev/engineering/content-contracts.md；实际JSON/CSV仍各有唯一源 |
| docs/production/demo-scope.md | dev/direction/demo-scope.md，保留已定/待实验的分界 |
| docs/production/engineering.md | dev/engineering/index.md 与对应契约，当前实现入口只引用实际文件 |
| docs/production/art.md | 拆到 production/art-direction.md、asset-pipeline.md；样板运行过程进入历史证据 |
| docs/production/audio.md | production/sound.md，并补齐可执行事件/导入/恢复/验收方法 |
| docs/production/district-*.md | dev/design/locations/ 的空间、建筑与场所规格，不再与玩家地点正文混同 |
| docs/production/place-catalog.json、city-story-map.json | dev/design/catalogs/，保留索引语义与稳定ID |
| docs/characters/characters.json、docs/quests/quests.json | dev/design/catalogs/，仅更新文档/数据路径等迁移字段 |
| docs/production/runtime-validation.md | dev/validation/runtime.md，保留已存在的分级验收与范围限制 |
| docs/production/asset-tool-review.md | 通用有效做法进入 production/asset-pipeline.md；一次性选型过程归 decisions 或旧证据 |
| docs/production/workflow.md | production/pipeline.md，生命周期方法，不保存当前任务状态 |
| docs/production/solo-workflow.md | 拆到 handbook/codex.md 与 handbook/tasks.md；旧字段教学与历史计数退出活动规范 |
| docs/conventions.md、docs/production/wiki.md | handbook/documentation.md 与 handbook/wiki.md |
| docs/templates/** | handbook/templates/，按百科/规格/制作/任务分别收敛模板 |
| todo/demo-progress.json/.md、旧roadmap/worklog | 冻结为历史输入；设计归docs，任务归task cards，证据保留并建立迁移映射 |
| todo 的独立素材/问卷/参考说明 | 长期规范归docs，当前工作转任务卡，历史来源归archive；不能只因位于todo就删除 |

一次迁移要同时更新调用者：叙事/故事/地图检查器、Wiki数据导出、Skills、游戏/工具 README、任务证据链接、构建测试和 CI。机器索引不是可随意删除的重复文案；更新字段前先验证消费者。

## 5. 发布方案

继续使用仓库锁定的 VitePress 1.x，不同时做框架升级。共享配置使用 player/dev 构建 profile，分开输出目录和缓存，dev profile 可按需链接/包含玩家资料，player profile 只产出玩家内容。

建议命令契约（实施后才成立）：

```text
bun run docs:dev:player
bun run docs:dev:dev
bun run docs:build:player
bun run docs:build:dev
bun run docs:build                 # 两者，保持旧入口可继续使用
```

页面入口、侧栏、local search、所有启用的 sitemap、预加载、public 复制、JSON/CSV和共享资产都按同一个受众规则生成。开发期服务器也要遵守相同边界，不能生产构建排除而 dev middleware 仍暴露全部源数据。

地图特别处理：现有完整 district.json 是源数据，玩家版若需要地图，应只导出玩家用途字段和对应表现数据，或有明确公开决定；不能为了百科地图把作者/制作字段默认公开。源码权限与发布隔离是两回事，方案不将目录当成访问控制。

迁移为玩家旧URL提供有限的redirect/alias与锚点对应，不保留重复正文；旧开发URL只在开发站重定向。构建输出中核对实际内容，而不是仅扫描链接名称。共享图片只保留实际引用且适用受众的文件。

## 6. 开发手册补齐清单

| 目标文档 | 采用来源 | 本项目必须补齐的内容 | 完成判断 |
|---|---|---|---|
| production/pipeline.md | Godogen、现有workflow | 类型化输入→制作→接入→证据→回写；不是所有任务强制录像 | 能从一个任务找到所需方法、命令和输出 |
| design/systems 与 quest spec | qiuaoru、abagames | 玩家目标/动作/信息/规则；事实、认知、本轮尝试、持久进度的责任 | 可从规则推导失败/恢复测试 |
| production/narrative.md | 现有create-case、poorvith | 因果、角色知情范围、分支、演出与环境信息 | 有完整QST-002样板，不复制百科全文 |
| production/art-direction.md | create-game-assets、Godogen | 视觉基准、silhouette/palette/material角色、参考家族 | 能判断一项新资产与既有视觉是否一致 |
| production/asset-pipeline.md | create-game-assets、Godogen | 尺度、pivot、alpha、色彩空间、命名、源/导出、来源、导入与QA | 用现有资产跑完整样板；上游阈值不当定值 |
| production/blender-animation.md | nside-blender-pipeline | 静态/绑定变换、GLB、clip、root motion/in-place、导入复验 | DCC步骤与游戏状态/表现检查都明确 |
| production/ui.md | game-ui-ux | 焦点、输入方式、返回路径、常规/异常状态、信息更新 | 能列出菜单/对话的导航与恢复检查 |
| production/sound.md | audio-design、现有audio | 事件、owner、start/stop、loop、并发、priority、bus、切场/暂停/存档 | 一张声音事件样板+可执行接入验收 |
| production/reference-analysis.md | nside-reference-analysis | 可见观察/估测/推测、时序与取景、实现要求与比较 | 已有参考可以形成对应场景的改动brief |
| engineering/content-contracts.md | bevy-skills与现有data | 内容ID、数据语义、错误、资产就绪与加载/退出、存档边界 | 未支持字段显式失败，代码与文档入口一致 |
| validation/runtime.md | Godogen、现有capture | 输入轨迹、状态断言、截图完成、失败、环境/版本、范围 | 复用现有Viewer命令，不冒充新玩法 |
| validation/visual-review.md 与 playtesting.md | abagames、poorvith | 自查/隔离评审/真实玩家区分，采样与限制 | 不能以看过设计的Agent替代陌生玩家 |

手册不是上游 Skill 翻译集。优先引用仍有效原版内容；项目特有的契约、路径与标准集中在docs。每篇方法能回答输入、前提、步骤、输出、检查、失败处理和调用入口。未知参数明确为实验，不填充看似专业的虚构预算。

保留原版权与许可。MIT复制内容保留版权/许可声明；Apache改编文件保留原归属、相关NOTICE并显著说明修改。把署名转移到清单之外不能作为删除原声明的理由。[审查报告E03/E04]

## 7. todo 新模型

### 7.1 里程碑与任务解耦

建议将旧M0–M7用于历史映射，新路线图按成果归并：

- G0：有效设计与制作基线（承接M0，已确认决定无需再次审批）。
- G1：可玩的机制/内容闭环（承接M1–M3的相关工作）。
- G2：完整代表性样板（M4）。
- G3：Demo内容集成（M5）。
- G4：真实试玩、兼容与发布候选（M6–M7）。

这是工作组织归并，不改变已定游戏内容。远期只保留目标、验收门槛和重大风险，当前/近期才展开卡片。重构本身用独立的短期里程碑，例如 DOCS-PIPELINE，不挤占“游戏已完成数量”。

### 7.2 唯一状态源与最小 schema

每张任务 Markdown 是任务状态唯一编辑源。首页与可开始任务列表从卡片生成，不再另设总JSON要求同步。标题取一级标题，角色/数值等长期规格通过specs引用。

```yaml
---
id: TASK-xxx
type: document
status: ready
milestone: DOCS-PIPELINE
depends_on: []
specs:
  - docs/dev/handbook/documentation.md
# migrated_from: [M0-02]            # 仅迁移需要时填写
# blocked_reason: ...              # blocked 时必需
# resolution: ...                  # cancelled 时必需
# acceptance:                      # done 时必需，引用真实记录
#   role: codex
#   revision: <被验收输入的commit或内容hash>
#   record: todo/evidence/TASK-xxx/run-id/result.md
---
# 任务标题

## 目标与范围
一个可以交付或回答的问题，以及本轮边界。

## 验收条件
明确可观察结果；实验任务写决策规则，失败假设也可形成完成交付。

## 当前工作与下一步
仅维护当前需要知道的信息，不固定展开六步教学和全部未来轮次。

## 结果与证据
结果、执行命令或走查方法、实际观察、限制、证据链接和写回的规格。
```

类型为 design/experiment/feature/asset/fix/document。状态为 backlog/ready/active/review/blocked/done/cancelled。

`review` 用于确实等待评审的任务；技术项可在通过适用检查后结束，无需作者批准每个函数。`done` 表示本任务验收成立，不能自动代表功能正式上线；实验得到否定结果也可done。标记被后续变更破坏时重开，保存旧证据并检查真实受影响依赖。

任务编号从未使用编号分配。旧对象ID不改；旧任务ID保留或建立显式alias/migrated_from。依赖只指任务ID，取消任务不自动满足依赖；需替换依赖或说明范围更改。accepted角色字段只表示记录类型，不认证人的身份。

### 7.3 任务与管线

设计类：问题/目标→备选与假设→设计交付→对应评审→写回设计。  
实验类：假设/判定规则→最小原型或探针→真实结果→采用/否定/未知。  
功能/资产类：规格→制作→接入→机器与画面证据→适用评审→回写。  
文档类：语义与来源→拆分/编写→引用/发布检查→样板走查。

同一模型按需要选用专业技能，不强制每次调用所有部门。纯百科编辑不更新开发任务完成状态，也不运行游戏capture。查询下一步只读。

### 7.4 看板与工具

用现有Bun生态实现轻量 tasks.mjs，避免新增数据库/服务。预期命令：tasks:list、tasks:sync、tasks:check。检查模式不写文件；生成结果稳定且无时间戳漂移；生成看板过期应失败而不是隐式修复。

README仅显示里程碑摘要、active、review、blocked、近期ready及明确的下一步。任务数量不是工时比例，不显示虚假的游戏完成百分比。

## 8. 两个完整工作样板

### 样板A：《最后的玩具》

百科页 `player/encyclopedia/story/main/last-toy.md` 保留米娜准备离城、玩具反复移位、收集者运输、处置后由她选择去向及回家的故事。使用章节剧透提示，正文不介绍JSON字段、节点编号、验证框架。

设计目录 `dev/design/quests/QST-002/` 保留 development.md、narrative.json 与后续实际对白/资产表。README以QST-002关联百科；development负责玩家动作、信息顺序、提前发现、隔离/跟随两条路线、双侧确认、退出/重试/存档。例：已知信息可保留；本次未提交操作可回滚；双侧确认后的持久结果不重复触发。

数据是设计输入还是运行输入保持真实标记：现有narrative.json尚未接入实际游戏，不因迁移变成已实现。文件移动时尽量保持数据字节不变；确需改路径字段列出允许变化，其余用语义对比守住。

近期任务卡“QST-002 文档职责迁移与关联复验”：type=document；产物是玩家页、开发规格、消费者路径和检查结果；验收包括剧情/对象ID未丢失、开发数据不进玩家包、四种设计路线的叙述不被改写、没有新声称的游戏完成状态。该任务完成不增加玩法完成度。

未来功能任务“提前找到玩具后，退出再进仍保留事实与认知”另建卡片，依赖运行与状态能力，只引用设计，不把本次文档检查当作游戏测试。

### 样板B：既有透明图片的规范化与验收

采用已有、来源明确的小图作为测试资产，不启动付费生图。

生产brief在所属资产包的现有说明维护：用途、实际显示尺寸、参考、alpha、允许变化与源文件。统一标准在production/asset-pipeline，实际结果在一张asset类型任务卡。

Codex读取create-game-assets和项目适配→运行修复后的asset_report（含颜色边界）→asset_preview三底色→人工查看预览并记录具体文件→若运行中已有该素材的真实使用场景，再做对应capture。没有接入场景时明确停留在“资产处理已验证”，不伪造游戏内合格。

验收：源图hash不变，尺寸/alpha/颜色限制符合，预览可查，来源完整；凡声明已游戏内验收须有真实运行证据。该样板同时验证Skill入口、手册、任务卡、工具与证据写回，避免新体系只存在于文档。

## 9. 实施顺序与回滚

| 阶段 | 实施内容 | 出口 |
|---|---|---|
| R0 门禁修复 | 修F01–F04，独立固定上游比对，保留署名；在宿主补齐discovery与代表性调用 | 错误样例失败，正常样例通过，未运行项单列 |
| R1 规范与迁移索引 | 落地handbook/documentation与tasks，按规则枚举每文件/旧任务，标明拆分与去向 | 没有未分类的活动文档/旧工作项，重要ID/来源受保护 |
| R2 双样板+发布profile | QST-002与资产样板，建立两个文档构建和导出边界 | 两个样板能真实走通；player包不混入开发资料 |
| R3 全量知识迁移 | 按已验过的方法拆分与补齐开发手册，更新索引/消费者/相对链接/旧URL | 内容与结构检查通过，手册可执行，无重复权威源 |
| R4 任务与入口切换 | 新卡片、生成看板、旧记录映射；更新AGENTS、router、guide/loop/review及CI | 一个状态源；旧流程不再调度新工作 |
| R5 回归与交付 | 构建双站、负例门禁、真实小任务、修复回归、留报告 | 所有必验项有真实结果，剩余限制清楚可承接 |

在工作分支中按阶段提交，避免同时修改玩法。每个切换提交应包含调用者更新和对应测试；回滚按提交还原整套源/消费者变更，不只还原Markdown。进入迁移前保存用户未提交内容，历史证据路径需要迁移映射而非静默丢弃。

## 10. 最终验收矩阵

| 检查 | 预期 |
|---|---|
| Skills 完整性 | schema、必需入口、文件覆盖、来源/改编、许可、引用均受检；缺失失败 |
| Codex 发现 | 根/game等请求cwd准确匹配，非空且必需技能enabled；实际版本记录 |
| Codex 行为 | 显式/隐式代表请求与反例实际测试，普通百科编辑不会启动制作/进度写入 |
| 资产工具 | N-1/N/N+1/N+2颜色边界、alpha、尺寸、覆盖保护均正确 |
| 文档语义 | 故事、角色关系、对象ID、设计约束和未决状态保持，不能只比页数 |
| 结构化数据 | 未授权字段不改，允许路径变化有记录，所有消费者已更新 |
| 玩家发布 | 页面、搜索、JSON/CSV、shared/public资产均符合受众规则；恶意/失误注入开发数据的测试会失败 |
| 引用 | 文档、Skill、模板、脚本、锚点、旧URL和历史证据可追溯 |
| 任务一致性 | 单状态源，唯一ID，无循环依赖，取消/重开规则与证据字段有效 |
| 工具确定性 | 连续生成无diff；check不写；陈旧生成物被识别 |
| 实际样板 | 一项真实文档/资产工具工作从新入口到验收与回写完整走通 |
| 游戏回归 | 仅运行受路径/工具变动实际影响的检查；无法运行明确NOT RUN，不冒称通过 |

## 11. Codex最终应交付

修复后的源码与回归测试、重构后的docs和开发手册、重新编排的任务卡与看板、更新后的Agent/构建/CI入口、实际逐文件及旧任务迁移映射、保留署名与许可、最终验收记录。

交付重点是可用的新体系，不是第二轮咨询报告；不以增加目录或文档字数作为完成标准。
