# N:SIDE Skills 整合验收报告

审查日期：2026-09-26  
远端基线：`Xarth-Mai/N-SIDE@a0deb64e1447d84ab7161e494ee1748de279090c`  
结论：**整合方向成立，可以保留现有专业资料与适配层；尚不满足“整合已完成、可依赖验收门禁放行”的标准。**

本报告基于 GitHub 连接器读取的固定版本源码、目录与清单，以及在审查沙箱中执行的独立复现实验。未修改远端仓库。优先级是本次修复与迁移的顺序，不是对整个项目质量的评分。

## 1. 审查边界与证据等级

GitHub 接口读取正常；沙箱 `git clone` 因无法解析 github.com 失败，且没有 Bun、Cargo、Codex CLI。本轮不是完整工作区构建，也没有观察用户机器的未提交改动。

为避免把环境限制变成空泛审阅，已将五个工具文件按连接器返回内容还原到临时目录，并计算 Git blob SHA，与 GitHub 返回的 SHA 对齐后运行其原函数。交付包只包含原创复现脚本和结果，不重新分发这些上游源码。

| 实际工作 | 证据与范围 |
|---|---|
| 目录、清单、入口核对 | 检查 `.agents/skills` 顶层 31 个目录；检查声明中的 22 个原样专业 Skill、3 个项目适配入口和6个既有项目/叙事入口的组织关系。这是静态目录盘点，不是31个宿主发现结果 |
| 原版保留抽样 | `create-game-assets` 的 SKILL.md blob 与 agents/assets/references/scripts 四个 Git tree 均与固定上游 commit 对应值相同；本地多一个 UPSTREAM.md |
| 归属声明核对 | 检查7项来源登记，读取 Apache NOTICE、qiuaoru 第三方方法论声明及本地改编文件归属；未完成全部来源文件的独立全量校验 |
| 检查器实验 | 原 `validate()` 函数，18个合成场景；使用 Node v22 和仅接受 JSON 格式测试 frontmatter 的 YAML 替代解析入口。没有修改验证逻辑，不覆盖 Bun YAML 兼容性 |
| 图片工具实验 | Python + Pillow 执行原 asset_report.py 和 asset_preview.py，9个场景；检查生成预览，无游戏内视觉结论 |
| 宿主探针实验 | 原 probe() 函数，3个模拟 RPC 场景；不是实际 Codex app-server 测试 |
| Wiki 导出实验 | 原 listWikiData()/copyWikiData()，模拟 player/dev 数据各一组，确认开发数据也被导出；不是 VitePress 完整构建 |
| 尚未运行 | 整仓 `bun run check:skills`、工具全集、Wiki build、Cargo、Vulkan capture、真实 Codex discovery/implicit routing、Blender/付费生图 |

完整实验结果见 `evidence/*.json`，复现入口见 `repro/README.md`。不能将此处的独立测试写成原仓库完整测试集通过。

## 2. 可以保留的整合成果

### 2.1 原版资料与适配层分工有实质内容

`nside/SKILL.md` 没有另起多引擎平台：它把 Bevy API 查询指向锁文件与源码；UI、对白、地图、音频分别映射回现有工程；资产 brief 与 manifest 沿用原有维护位置。这些是有效的项目适配，不应因这次重构全部推倒。

`nside-blender-pipeline` 区分静态模型与绑定动画的变换处理，保留源文件，并避免固定骨架、全量 Apply Transforms 和自动引入 Add-on。`nside-reference-analysis` 已从网页复刻改成镜头、空间、灯光、材质、运动与反馈分析。`content-and-review.md` 也区分操作信息可理解性与剧情真相揭示。[S03–S05]

### 2.2 资产工作流不是仅复制一篇简介

抽样原版目录中包含脚本、模板、配置与参考资料，Git tree/blob 对比支持其原样保留声明。可继续使用，但“与上游一致”不是“没有 bug”，F03 就是实际例子。[S06–S07]

### 2.3 运行验收的范围表述基本准确

`runtime-validation.md` 明确现有 capture 是 Viewer 相机输入与渲染，而不是人物碰撞、任务或角色动画；固定 timestep 也未被误写成跨平台像素确定性。原流程保留“机器断言、视觉自查、真实体验评审”的分工，值得作为新 `docs/dev/validation/` 的基础。[S08]

### 2.4 署名有明确留存

Apache NOTICE 保留 Abhishek Barali 与 contributors；qiuaoru 的声明保留六边形老闪（张鹏）的原始方法论归属及维护者关于授权的说明。本地 Blender、参考分析与运行验收文件有改编归属。这里只确认可见文件与抽样内容；不把维护者声明升级为独立核实的授权原件。[S09–S11]

## 3. 已确认问题

### F01 · P1 · Skills 检查器对缺失与空清单 fail-open

位置：`tools/validate-skills.mjs`，manifest 初始化、读取与最终结果。

实测：删除 manifest、替换为空 sources/skills/references、移除全部 Skill 目录时，都可能得到 `ok: true`。正常文件和声明同时消失，检查器便失去了预期集合。manifest 为 `{}` 时不是清楚报告 schema 错误，而是抛出未结构化异常。[S01；evidence/validator-fixtures.json]

处理：manifest 必须存在并验证版本/字段；本仓库的必需项目入口必须存在；枚举实际文件与受管条目双向对照，允许有明确用途的本地非导入文件，但不能把“未登记”默认为合规。预期集合来自维护策略和清单，而不是写死31个目录。

验收：缺失、空清单、不支持版本、字段类型错误、重复来源/路径、缺少必需入口均非零退出且有明确诊断；正常配置不误拒绝。

### F02 · P1 · 完整性与可用性检查范围窄于“整合验收”的含义

位置：`tools/validate-skills.mjs`、`tools/tests/validate-skills.test.mjs`、`UPSTREAM.md` 与 manifest 的 optional_upstream_links。

实测的漏检包括：导入目录新增未登记脚本、不存在的命令路径、失效锚点、坏的 agents/openai.yaml、third_party 中参考 Markdown 的失效链接。修改“原样文件”后连同本地 hash 一起更新，也无法仅凭这套自洽检查证明其等同于上游。[S01–S02]

现有 optional 机制只验证 URL 前缀，并豁免原相对链接不存在；测试甚至把删除参考文件后加 optional 登记视为通过。`bevy-core-concepts/UPSTREAM.md` 明确原相对链接被保留，实际入口仍可能指向未安装目录。替代链接有价值，但登记豁免不等于修复入口。[S12]

处理：分离“本地完整性”“固定上游来源比对”“实际引用可达性”；关键 scripts/metadata/required references 结构化登记，不要求用脆弱正则理解所有自然语言。对已证实的断链优先做小幅本地链接修正，保留作者并标记改编文件；未改文件继续按原样校验。可选参考无需全量安装，也不要创建假 Skill 占位。

验收：增加相关失败样例；固定版本比对从独立上游读取文件或 Git 对象，不仅比较本地哈希；网上来源不可达明确单独记录。

### F03 · P1（资产硬约束场景）· 颜色数量上限有 off-by-one 漏报

位置：`.agents/skills/create-game-assets/scripts/asset_report.py`。

`inspect()` 允许 `getcolors(max_colors + 1)` 返回 N+1 个颜色；主检查只在 color_count 为字符串时判超限，没有判断整数是否大于 N。

原文件实测：

| 图片颜色数 | 参数 | 预期退出码 | 实际退出码 |
|---|---|---:|---:|
| 1 | `--max-colors 1` | 0 | 0 |
| 2 | `--max-colors 1` | 1 | **0** |
| 3 | `--max-colors 1` | 1 | 1 |

处理：同时拒绝无法精确计数的超限结果，以及精确计数大于预算的结果；增加 N-1/N/N+1/N+2 边界测试。因为这是原版 Apache 来源文件，修复时显著标注修改，保留 NOTICE/许可，并将该文件登记成补丁版本，不能只改 hash 后仍称逐字节原样。[S13；evidence/asset-tests.json]

同批正向结果：尺寸错误、RGB 缺 alpha、透明切图、全透明拒绝、不透明拒绝和源文件覆盖拒绝按预期工作。预览只证明本次合成样例的处理，不证明实际美术质量。

### F04 · P2 · 宿主发现探针对空预期与重复 cwd 的判定不完整

位置：`tools/probe_skills.py`。

它用本地 glob 生成 expected，并只检查 entries 长度等于2。模拟 RPC 实验中：没有任何 Skill 时两个空结果可 PASS；返回两次仓库根 cwd、漏掉 game cwd，也可 PASS。[S14；evidence/discovery-fixtures.json]

处理：要求必需集合非空，核对实际 cwd 集合准确等于请求集合、每个 cwd 唯一、必需技能可用；处理非预期响应。保留其“只做宿主发现，不证明隐式调用”的正确范围声明。

真实 Codex 发现、显式点名、隐式匹配、根目录/game 子目录和反向请求仍需在用户环境补测。官方文档将 skills/list 与 turn/start 调用区分开，发现列表不能替代执行测试。[E01–E02]

### F05 · P1（文档重构切换前）· 玩家/开发尚未形成发布边界

位置：`docs/.vitepress/config.mjs`、`sidebar.mjs`、`tools/wiki-data.mjs`。

现状是同一 docs 根、同一 local search 与两组侧栏。`copyWikiData(docsRoot, outDir)` 递归导出 JSON/CSV；projectAssets 中还直接配置了完整 district.json。这是旧的混合 Wiki 设计，不是在声称现有站点泄露了秘密。[S15–S16]

实测：仅新增 `player/` 和 `dev/` 目录后，原函数仍然导出 dev/design/quests/narrative.json 与 dialogue.csv。只改目录或侧栏不能满足新的发布目标。[evidence/wiki-export-fixture.json]

处理：共享配置下建立 player/dev 两个构建 profile，各自限定页面、搜索、公共静态文件与结构化数据/共享资产导出。玩家需要的地图另行制定允许字段投影或明确批准完整公开，不能沿用无条件导出。玩家版本只保留玩家路由的兼容跳转，不导出旧开发页面正文。

### F06 · P1（新管线切换前）· 新专业层仍由旧进度体系管理

位置：`AGENTS.md`、`.agents/skills/nside/SKILL.md`、既有 guide/work-loop/review、`todo/demo-progress.json`。

新适配层主动将进度和阶段放行交给旧三入口；根入口仍指定巨大进度 JSON 为唯一编辑源。新能力有了，但任务组织尚未换代。[S03、S17]

旧进度仍将已经选择首委托的问题保留成“采用《最后的玩具》还是另选”，而执行备注已走到具体节点审查；M1 首运行骨架依赖整个 M0 出口。这说明当前字段混有教学、旧提问、长期规格与执行状态，不应整体搬进新卡片。[S18]

处理：新 Markdown 任务卡为唯一执行事实源；路线图保留成果门槛而非固定分母；旧61项逐项映射为决定、任务、合并项或历史证据。切换时一次更新所有活动入口，而不是维持双状态系统。

### F07 · P2 · 开发规范仍需要项目化，而不是增加更多 Skills

现有 `production/` 中混有方向、具体空间规格、工程现状和制作方法；audio.md 已列重要检查项目，但不足以承担完整的声音事件接入、恢复与验收操作手册。美术内容丰富，应拆分“方向”“资产契约”“制作方法”“本次样板记录”，不应一律删短。新适配层的许多做法仍仅位于 Skills 内，没有稳定开发手册入口。[S04、S19–S20]

处理：按方案补齐职责明确的开发文档，将通用操作留在原版 Skill，把 n-side 具体契约与标准写入 docs/dev。避免将全部上游阈值、插件和题材偏好照搬为强规范。

## 4. 本轮结论矩阵

| 维度 | 结论 |
|---|---|
| 原版/参考/改编的组织方式 | 静态核对成立，继续沿用 |
| create-game-assets 原样目录 | 固定版本 Git 对象抽样通过；不是全库来源证明 |
| 作者与来源登记 | 已见7来源登记及关键归属文件；全量许可/来源核验仍待补齐 |
| 现有 Skill 门禁 | **不通过**：F01/F02 已复现 |
| 图片约束工具 | **部分通过**：F03 超色边界漏报 |
| 宿主发现探针 | **需修复**：模拟测试揭示F04；真实宿主 NOT RUN |
| 项目适配内容 | 方法与边界基本合理；隐式路由和工具联调 NOT RUN |
| docs/todo 新管线 | 尚未建立；按重构方案实施 |
| 游戏运行/体验 | 本轮 NOT RUN，不作完成判断 |

推荐放行条件：修复F01–F04并在目标环境复验；实施F05/F06的文档/任务切换；补齐关键制作手册与真实工作流试运行。可以先使用受控的专业参考，不应把它们的安装或局部脚本通过折算成游戏完成度。

## 5. 源码索引与固定版本定位

所有 S 编号都是仓库路径；除特别说明外，固定到本文基线。浏览方式：`https://github.com/Xarth-Mai/N-SIDE/blob/a0deb64e1447d84ab7161e494ee1748de279090c/<path>`。

- S01：tools/validate-skills.mjs，blob `795ce3230c898d536003260b014c5c598c171839`。
- S02：tools/tests/validate-skills.test.mjs。
- S03：.agents/skills/nside/SKILL.md。
- S04：.agents/skills/nside/references/content-and-review.md。
- S05：.agents/skills/nside-blender-pipeline/SKILL.md；nside-reference-analysis/SKILL.md。
- S06：.agents/skills/create-game-assets/ 的 Git tree `dceeb45b27402a2291416879de8416375fd236af`。
- S07：上游 gamedev-skills/awesome-gamedev-agent-skills@44888f28ff918357ad82c4473352c60a1c5bde5b 的 skills/disciplines/create-game-assets/。
- S08：docs/production/runtime-validation.md；tools/capture.py。
- S09：THIRD_PARTY_NOTICES.md；third_party/skills/manifest.json。
- S10：third_party/skills/awesome-gamedev-agent-skills/NOTICE。
- S11：third_party/skills/game-design-agent-skills/THIRD_PARTY_NOTICES.md。
- S12：.agents/skills/bevy-core-concepts/UPSTREAM.md；manifest 中 optional_upstream_links。
- S13：.agents/skills/create-game-assets/scripts/asset_report.py，blob `6eb94d625ee1574356019181dc6168855343f9dd`；tools/asset_preview.py，blob `0a3498e6dcf085cff295bc2e4a0f72c00e5dc5d3`。
- S14：tools/probe_skills.py，blob `f06b558713449438f723f201dac6650021a57265`。
- S15：docs/.vitepress/config.mjs；docs/.vitepress/sidebar.mjs。
- S16：tools/wiki-data.mjs，blob `fa0a772a50579bf502e65fda1b5b2f06e0f52550`。
- S17：AGENTS.md；todo/README.md。
- S18：todo/demo-progress.json；todo/demo-roadmap.md；docs/production/solo-workflow.md。
- S19：docs/conventions.md；docs/production/wiki.md；docs/production/workflow.md。
- S20：docs/production/art.md；audio.md；engineering.md；docs/quests/QST-002/README.md、development.md。

外部规则依据（2026-09-26读取）：
- E01：OpenAI Skills 文档：`https://developers.openai.com/codex/skills/`（当前跳转到官方 Learn 文档）。
- E02：OpenAI App Server 文档：`https://developers.openai.com/codex/app-server/`，skills/list 与显式 skill 输入。
- E03：Apache-2.0 第4节：`https://www.apache.org/licenses/LICENSE-2.0`，分发、原归属与修改说明。
- E04：MIT 许可：`https://opensource.org/license/mit`，版权与许可声明留存。
- E05：VitePress 1.x 配置：`https://vuejs.github.io/vitepress/v1/reference/site-config`。重构不要求升级到2.0。
