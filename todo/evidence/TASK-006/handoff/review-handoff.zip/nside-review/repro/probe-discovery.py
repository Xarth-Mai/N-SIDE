from pathlib import Path
import importlib.util, asyncio, json, tempfile, hashlib, sys
from unittest.mock import patch, AsyncMock
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve(); output=Path(sys.argv[2] if len(sys.argv)>2 else 'discovery-fixtures.json'); source=repo/'tools/probe_skills.py'
b=source.read_bytes();h=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
print('source blob:',h)
spec=importlib.util.spec_from_file_location('subject',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Writer:
 def write(self,data): pass
 async def drain(self): pass
class Reader:
 def __init__(self,messages): self.messages=iter(messages)
 async def readline(self):
  try:return (json.dumps(next(self.messages))+'\n').encode()
  except StopIteration:return b''
class FakeProcess:
 def __init__(self,data):
  self.stdin=Writer();self.stdout=Reader([{'id':1,'result':{'userAgent':'TEST-STUB-NOT-CODEX'}},{'id':2,'result':{'data':data}}]);self.returncode=None
 def terminate(self):self.returncode=0
 def kill(self):self.returncode=-9
 async def wait(self):return self.returncode
results=[]
for kind in ['valid','empty_expected','duplicate_cwd']:
 with tempfile.TemporaryDirectory(prefix='nside-probe-') as tmp:
  root=Path(tmp);(root/'game').mkdir();skills=[]
  if kind!='empty_expected':
   p=root/'.agents/skills/sample/SKILL.md';p.parent.mkdir(parents=True);p.write_text('fixture')
   skills=[{'name':'sample','path':str(p),'enabled':True}]
  data=[{'cwd':str(root),'skills':skills,'errors':[]},{'cwd':str(root if kind=='duplicate_cwd' else root/'game'),'skills':skills,'errors':[]}]
  with patch.object(m,'ROOT',root),patch.object(m.shutil,'which',return_value='/test/stub/codex'),patch.object(m.asyncio,'create_subprocess_exec',new=AsyncMock(return_value=FakeProcess(data))):
   r=asyncio.run(m.probe(None));results.append({'case':kind,'expected':'PASS' if kind=='valid' else 'FAIL','actual':r});print(kind,r['status'])
output.write_text(json.dumps({'source_blob_sha':h,'tested_file':str(source),'scope':'Exact repository probe() on simulated RPC responses; not an installed Codex host test','results':results},ensure_ascii=False,indent=2))
