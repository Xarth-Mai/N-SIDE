from pathlib import Path
from PIL import Image, __version__ as pil_version
import json, subprocess, sys, hashlib
base=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve(); out=Path(sys.argv[2] if len(sys.argv)>2 else 'audit-asset-output').resolve(); out.mkdir(parents=True,exist_ok=True); cases=out/'asset-fixtures'; cases.mkdir(exist_ok=True)
for n in (1,2,3):
 im=Image.new('RGB',(n,1)); im.putdata([(i*70,0,0) for i in range(n)]); im.save(cases/f'{n}-colors.png')
im=Image.new('RGBA',(16,16),(0,0,0,0)); im.putpixel((8,8),(255,100,50,255)); im.save(cases/'cutout.png')
Image.new('RGBA',(16,16),(0,0,0,0)).save(cases/'invisible.png')
report=base/'.agents/skills/create-game-assets/scripts/asset_report.py'; preview=base/'tools/asset_preview.py'
results=[]
def run(name,args,expected):
 p=subprocess.run([sys.executable,*map(str,args)],capture_output=True,text=True,timeout=10)
 try: data=json.loads(p.stdout)
 except: data={'stdout':p.stdout,'stderr':p.stderr}
 results.append({'name':name,'args':list(map(str,args)),'expected_exit':expected,'actual_exit':p.returncode,'output':data,'matches_expected':p.returncode==expected})
for n in (1,2,3): run(f'{n}_colors_limit_1',[report,cases/f'{n}-colors.png','--max-colors','1','--json'],0 if n==1 else 1)
run('wrong_dimensions',[report,cases/'cutout.png','--expect-size','32x32','--json'],1)
run('missing_alpha',[report,cases/'1-colors.png','--require-alpha','--json'],1)
run('valid_cutout',[preview,cases/'cutout.png','--out',cases/'preview.png','--display-size','64x64','--require-cutout'],0)
run('reject_invisible',[preview,cases/'invisible.png','--out',cases/'invisible-preview.png','--display-size','64x64','--require-cutout'],1)
run('reject_opaque',[preview,cases/'1-colors.png','--out',cases/'opaque-preview.png','--display-size','64x64','--require-cutout'],1)
run('reject_overwrite',[preview,cases/'cutout.png','--out',cases/'cutout.png','--display-size','64x64'],1)
(out/'asset-tests.json').write_text(json.dumps({'tested_sources':{str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (report,preview)},'scope':'Exact repository scripts from pinned blobs, synthetic assets; no game rendering','python':sys.version,'Pillow':pil_version,'results':results},ensure_ascii=False,indent=2))
for r in results: print(r['name'],r['actual_exit'],'expected',r['expected_exit'])
