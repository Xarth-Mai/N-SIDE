# 复现实验

这些脚本读取目标仓库的现有工具，在临时目录构造输入，输出结果；不会修改目标仓库。它们不是完整仓库测试，也不是新的生产检查器。

建议先在报告固定基线的单独工作副本运行，再在修复后比较。同一结果里保留实际源文件版本，不能把本包原先记录的baseline自动视为后来运行的版本。

从本交接包根目录执行（fish）：

```fish
set repo /path/to/N-SIDE
set evidence /tmp/nside-review-repro
mkdir -p $evidence
node repro/probe-validator.mjs $repo $evidence/validator-fixtures.json
python3 repro/probe-assets.py $repo $evidence/assets
python3 repro/probe-discovery.py $repo $evidence/discovery-fixtures.json
node repro/probe-wiki.mjs $repo $evidence/wiki-export-fixture.json
```

## 范围

`probe-validator.mjs` 导入原validate()。所有样例frontmatter是合法JSON（YAML子集），用JSON.parse替代Bun.YAML.parse；不修改其他逻辑。它不测试Bun YAML兼容性，也不是bun run check:skills的替代。

`probe-assets.py` 真正运行仓库asset_report.py、asset_preview.py，需要Python和Pillow。生成的像素图是程序测试样例，不是n-side美术或游戏画面。

`probe-discovery.py` 运行原probe()，替换的是RPC进程和返回数据。它只检验客户端对异常返回的处理，不能证明实际Codex宿主行为。

`probe-wiki.mjs` 运行原Wiki数据枚举与复制函数；模拟将目录分为player/dev后的结果，不会启动VitePress。修复后的函数接口可能改变，此时应把这些样例迁入正式单元测试，而不是为保持脚本形式保留旧接口。

脚本打印观察，不都使用退出码表达预期结论。具体结果看JSON的actual/expected字段，正式CI需要将预期变为断言。包中的evidence是此次审查实际产物，不是承诺未来所有版本产生相同结果。
