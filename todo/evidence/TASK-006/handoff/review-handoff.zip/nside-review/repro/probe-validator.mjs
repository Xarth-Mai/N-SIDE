import {mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, symlinkSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const repo=resolve(process.argv[2] ?? '.');
const output=resolve(process.argv[3] ?? 'validator-fixtures.json');
const {validate}=await import(pathToFileURL(join(repo,'tools/validate-skills.mjs')));
// All fixture frontmatter is JSON, a valid YAML subset. This substitutes parsing
// only, not validation logic; it is NOT a Bun or Codex integration test.
globalThis.Bun={YAML:{parse:JSON.parse}};
const sha=s=>createHash('sha256').update(s).digest('hex');
const results=[];
const initialText='---\n'+JSON.stringify({name:'sample',description:'fixture'})+'\n---\n# Sample\n';
function execute(name, mutate, expectedReject=true){
 const root=mkdtempSync(join(tmpdir(),'nside-review-'));
 const put=(p,s)=>{mkdirSync(dirname(join(root,p)),{recursive:true});writeFileSync(join(root,p),s)};
 const state={root,put,text:initialText,manifest:{sources:[{id:'sample',repo:'https://github.com/example/sample',commit:'a'.repeat(40),author:'Fixture author',license:'MIT',license_files:[{local_path:'third_party/skills/sample/LICENSE',sha256:sha('Fixture license\n')}]}],skills:[{name:'sample',source:'sample',local_path:'.agents/skills/sample',files:[{path:'SKILL.md',sha256:sha(initialText)}]}],references:[]}};
 put('.agents/skills/sample/SKILL.md',initialText);put('third_party/skills/sample/LICENSE','Fixture license\n');
 mutate(state);
 if(state.manifest!==null) put('third_party/skills/manifest.json',typeof state.manifest==='string'?state.manifest:JSON.stringify(state.manifest));
 let outcome;
 try{outcome=validate(root)}catch(e){outcome={threw:true,error:e.message}};
 results.push({name,expectedReject,actual:outcome,assessment:!expectedReject ? outcome.ok===true?'positive-control-pass':'unexpected-reject' : outcome.threw?'unstructured-error':outcome.ok?'false-pass':'detected'});
 rmSync(root,{recursive:true,force:true});
}
function rewrite(s,t){s.text=t;s.put('.agents/skills/sample/SKILL.md',t);s.manifest.skills[0].files[0].sha256=sha(t)};
execute('valid_baseline',()=>{},false);
execute('missing_manifest',s=>s.manifest=null);
execute('empty_manifest',s=>s.manifest={sources:[],skills:[],references:[]});
execute('empty_repository',s=>{s.manifest=null;rmSync(join(s.root,'.agents'),{recursive:true});});
execute('malformed_manifest_json',s=>s.manifest='{bad');
execute('malformed_manifest_shape',s=>s.manifest={});
execute('deleted_license',s=>rmSync(join(s.root,'third_party/skills/sample/LICENSE')));
execute('modified_recorded_skill',s=>s.put('.agents/skills/sample/SKILL.md',s.text+'Changed\n'));
execute('extra_untracked_script',s=>s.put('.agents/skills/sample/scripts/unrecorded.py','print("unrecorded")\n'));
execute('dangling_markdown_link',s=>rewrite(s,s.text+'[missing](missing.md)\n'));
execute('dangling_anchor',s=>rewrite(s,s.text+'[missing](SKILL.md#no-such-anchor)\n'));
execute('missing_code_command',s=>rewrite(s,s.text+'Run `python3 scripts/not-installed.py` before proceeding.\n'));
execute('optional_missing_link_with_fabricated_pinned_url',s=>{rewrite(s,s.text+'[required instructions](../absent/SKILL.md)\n');s.manifest.skills[0].optional_upstream_links=[{from:'SKILL.md',target:'../absent/SKILL.md',url:'https://github.com/example/sample/blob/'+ 'a'.repeat(40)+'/nonexistent'}]});
execute('uninspected_reference_markdown',s=>{const t='[must read](not-found.md)\n';s.put('third_party/skills/sample/references/readme.md',t);s.manifest.references=[{name:'ref',source:'sample',local_path:'third_party/skills/sample/references',files:[{path:'readme.md',sha256:sha(t)}]}]});
execute('bad_agents_metadata',s=>s.put('.agents/skills/sample/agents/openai.yaml','interface: [invalid yaml\n'));
execute('duplicate_source',s=>s.manifest.sources.push({...s.manifest.sources[0]}));
execute('deleted_recorded_skill',s=>rmSync(join(s.root,'.agents/skills/sample/SKILL.md')));
execute('removed_license_and_manifest_entry',s=>{s.manifest={sources:[],skills:[],references:[]};rmSync(join(s.root,'third_party/skills/sample/LICENSE'))});
writeFileSync(output,JSON.stringify({review_baseline:'a0deb64e1447d84ab7161e494ee1748de279090c',tested_file:join(repo,'tools/validate-skills.mjs'),tested_sha256:sha(readFileSync(join(repo,'tools/validate-skills.mjs'))),review_source_blob_sha:'795ce3230c898d536003260b014c5c598c171839',runtime:process.version,scope:'Exact repository validate() function on synthetic fixtures; JSON-only YAML parsing shim; no Bun/Codex/full-repo test',results},null,2));
for(const r of results) console.log(r.name.padEnd(52),r.assessment);
