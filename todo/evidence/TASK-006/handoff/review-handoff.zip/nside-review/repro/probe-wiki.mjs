import {createHash} from 'node:crypto';
import {mkdtempSync,mkdirSync,writeFileSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname,relative,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const repo=resolve(process.argv[2]??'.');const destination=resolve(process.argv[3]??'wiki-export-fixture.json');
const {listWikiData,copyWikiData}=await import(pathToFileURL(join(repo,'tools/wiki-data.mjs')));
const temp=mkdtempSync(join(tmpdir(),'nside-wiki-'));const root=join(temp,'docs');const out=join(temp,'dist');
for (const p of ['player/encyclopedia/catalog.json','dev/design/quests/narrative.json','dev/design/quests/dialogue.csv']){const f=join(root,p);mkdirSync(dirname(f),{recursive:true});writeFileSync(f,p.endsWith('.json')?'{}':'id,text\n');}
const files=listWikiData(root).map(p=>relative(root,p));const copied=copyWikiData(root,out);
const result={review_baseline:'a0deb64e1447d84ab7161e494ee1748de279090c',tested_file:join(repo,'tools/wiki-data.mjs'),tested_sha256:createHash('sha256').update(readFileSync(join(repo,'tools/wiki-data.mjs'))).digest('hex'),scope:'Original listWikiData/copyWikiData on synthetic proposed directories; not a VitePress build',files,copied,developer_files_included:files.some(x=>x.startsWith('dev/'))};
writeFileSync(destination,JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));rmSync(temp,{recursive:true,force:true});
